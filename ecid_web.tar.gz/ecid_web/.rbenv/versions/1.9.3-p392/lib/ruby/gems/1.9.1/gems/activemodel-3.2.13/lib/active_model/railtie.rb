require "active_model"
require "rails"