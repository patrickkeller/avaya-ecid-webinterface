module Arel
  ###
  # This is deprecated.  Fix rails, then remove this.
  module Relation
  end
end
