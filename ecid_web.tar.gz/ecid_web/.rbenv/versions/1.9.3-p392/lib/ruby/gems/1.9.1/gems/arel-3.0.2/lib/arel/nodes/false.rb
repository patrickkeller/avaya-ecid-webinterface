module Arel
  module Nodes
    class False < Arel::Nodes::Node
    end
  end
end
