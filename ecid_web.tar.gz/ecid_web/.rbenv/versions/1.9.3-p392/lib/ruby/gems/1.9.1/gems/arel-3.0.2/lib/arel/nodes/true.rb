module Arel
  module Nodes
    class True < Arel::Nodes::Node
    end
  end
end
