module Libv8
  VERSION = "3.11.8.13"
end
