module Arel
  module Nodes
    class Distinct < Arel::Nodes::Node
    end
  end
end
