module Arel
  module Nodes
    class Ordering < Unary
    end
  end
end
